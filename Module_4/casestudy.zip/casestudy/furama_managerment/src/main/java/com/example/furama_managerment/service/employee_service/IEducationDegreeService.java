package com.example.furama_managerment.service.employee_service;

import com.example.furama_managerment.model.employee.EducationDegree;

import java.util.List;

public interface IEducationDegreeService {
    List<EducationDegree> findAll();
}
