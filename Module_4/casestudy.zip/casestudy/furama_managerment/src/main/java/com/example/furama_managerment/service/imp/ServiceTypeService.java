package com.example.furama_managerment.service.imp;

import com.example.furama_managerment.service.service_service.IServiceTypeService;

public class ServiceTypeService implements IServiceTypeService {
}
