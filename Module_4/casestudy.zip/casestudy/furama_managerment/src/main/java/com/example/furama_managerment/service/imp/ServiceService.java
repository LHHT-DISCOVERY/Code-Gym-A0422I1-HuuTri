package com.example.furama_managerment.service.imp;

import com.example.furama_managerment.service.service_service.IServiceService;

public class ServiceService implements IServiceService {
}
