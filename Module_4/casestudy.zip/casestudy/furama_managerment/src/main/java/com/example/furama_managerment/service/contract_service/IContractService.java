package com.example.furama_managerment.service.contract_service;

public interface IContractService {
}
