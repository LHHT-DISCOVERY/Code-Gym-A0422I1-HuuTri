package com.example.furama_managerment.repository.service_repository;

public interface IServiceTypeRepository {
}
