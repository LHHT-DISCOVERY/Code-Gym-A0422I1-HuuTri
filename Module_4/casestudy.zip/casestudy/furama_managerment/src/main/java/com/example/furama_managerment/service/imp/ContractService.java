package com.example.furama_managerment.service.imp;

import com.example.furama_managerment.service.contract_service.IContractService;

public class ContractService implements IContractService {
}
