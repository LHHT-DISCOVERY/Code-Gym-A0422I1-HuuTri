package com.example.furama_managerment.service.imp;

import com.example.furama_managerment.service.contract_service.IAttachServiceService;

public class AttachServiceService implements IAttachServiceService {
}
