package com.example.furama_managerment.service.imp;

import com.example.furama_managerment.service.employee_service.IRoleService;

public class RoleService implements IRoleService {
}
