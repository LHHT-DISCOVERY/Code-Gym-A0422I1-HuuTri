package com.example.furama_managerment.service.imp;

import com.example.furama_managerment.service.employee_service.IUserService;

public class UserService implements IUserService {
}
