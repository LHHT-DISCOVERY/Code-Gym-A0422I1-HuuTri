package com.example.furama_managerment.repository.employee_repository;

public interface IRoleRepository {
}
