package com.example.furama_managerment.service.employee_service;

import com.example.furama_managerment.model.employee.Position;

import java.util.List;

public interface IPositionService {
    List<Position>  findALl();
}
