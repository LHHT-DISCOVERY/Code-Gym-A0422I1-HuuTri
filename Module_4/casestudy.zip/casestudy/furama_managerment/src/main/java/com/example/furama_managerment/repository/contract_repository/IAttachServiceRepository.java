package com.example.furama_managerment.repository.contract_repository;

public interface IAttachServiceRepository {
}
