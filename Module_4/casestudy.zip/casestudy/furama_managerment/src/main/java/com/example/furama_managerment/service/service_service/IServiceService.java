package com.example.furama_managerment.service.service_service;

public interface IServiceService {
}
