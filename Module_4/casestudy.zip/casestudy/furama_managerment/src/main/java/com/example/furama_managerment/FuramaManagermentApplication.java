package com.example.furama_managerment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuramaManagermentApplication {

    public static void main(String[] args) {
        SpringApplication.run(FuramaManagermentApplication.class, args);
    }

}
