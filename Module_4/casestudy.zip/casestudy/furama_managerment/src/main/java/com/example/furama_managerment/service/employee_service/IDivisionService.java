package com.example.furama_managerment.service.employee_service;

import com.example.furama_managerment.model.employee.Division;

import java.util.List;

public interface IDivisionService{
    List<Division> findAll();
}
