package com.example.furama_managerment.service.employee_service;

public interface IRoleService {
}
