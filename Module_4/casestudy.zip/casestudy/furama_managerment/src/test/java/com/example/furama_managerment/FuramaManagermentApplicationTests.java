package com.example.furama_managerment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuramaManagermentApplicationTests {

    @Test
    void contextLoads() {
    }

}
